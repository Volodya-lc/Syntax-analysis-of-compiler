import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/** 主编译器类，负责整个编译过程的控制流程。 */
public class Compiler {

    public static void main(String[] args) {
        try {
            // 输入和输出文件路径
            String inputFile = "testfile.txt";
            String outputFile = "output.txt";

            // 读取输入文件
            readInputFile(inputFile);

            // 设置保留字和单字符映射
            yingshe.setReservedMap();
            yingshe.setSingleMap();

            // 词法分析
            performLexicalAnalysis();

            // 语法分析
            yvfafenxi.CompUnit();

            // 将语法分析结果写入输出文件
            writeOutputFile(outputFile);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /** 读取输入文件内容。 */
    private static void readInputFile(String inputFile) throws IOException {
        try (FileReader fileReader = new FileReader(inputFile);
             BufferedReader bufferedReader = new BufferedReader(fileReader)) {

            String line;
            while ((line = bufferedReader.readLine()) != null) {
                yingshe.inputContent += line + "\n";
            }
        }
    }

    /** 执行词法分析。 */
    private static void performLexicalAnalysis() {
        while (cifafenxi.indexs < yingshe.inputContent.length()) {
            cifafenxi.getSym();
        }
    }

    /** 将语法分析结果写入输出文件。 */
    private static void writeOutputFile(String outputFile) throws IOException {
        try (FileWriter fileWriter = new FileWriter(outputFile);
             BufferedWriter bufferedWriter = new BufferedWriter(fileWriter)) {

            for (String output : yvfafenxi.answer) {
                bufferedWriter.write(output + "\n");
                System.out.println(output);
            }
        }
    }
}
