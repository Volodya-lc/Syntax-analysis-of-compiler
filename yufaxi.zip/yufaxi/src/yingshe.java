import utils.tree_node;
import java.util.ArrayList;
import java.util.HashMap;

// 全局类，包含一些全局变量和方法
public class yingshe {
    // 保留字映射表，将保留字映射到对应的Token
    public static HashMap<String, String> reservedMap = new HashMap<>();

    // 单字符映射表，将单字符符号映射到对应的Token
    public static HashMap<Character, String> singleMap = new HashMap<>();

    // 输入源代码的字符串内容
    public static String inputContent = "";

    // 存储词法分析过程中的错误信息
    public static ArrayList<String> error_output = new ArrayList<>();

    // 全局符号表，存储全局变量和函数信息
    public static HashMap<String, fuhaobiao> globalTable = new HashMap<>();

    // 全局函数表，存储全局函数信息
    public static HashMap<String, fuhaobiao> globalFuncTable = new HashMap<>();

    // 层次符号表，存储每个函数的局部变量和参数信息
    public static HashMap<String, HashMap<String, fuhaobiao>> LayerTable = new HashMap<>();

    // 语法树的根节点
    public static tree_node head;

    // 设置单字符映射表，将单字符符号映射到对应的Token
    public static void setSingleMap() {
        singleMap.put('+', "PLUS");
        singleMap.put('-', "MINU");
        singleMap.put('*', "MULT");
        singleMap.put('/', "DIV");
        singleMap.put('%', "MOD");
        singleMap.put(';', "SEMICN");
        singleMap.put(',', "COMMA");
        singleMap.put('(', "LPARENT");
        singleMap.put(')', "RPARENT");
        singleMap.put('[', "LBRACK");
        singleMap.put(']', "RBRACK");
        singleMap.put('{', "LBRACE");
        singleMap.put('}', "RBRACE");
    }

    // 设置保留字映射表，将保留字映射到对应的Token
    public static void setReservedMap() {
        reservedMap.put("main", "MAINTK");
        reservedMap.put("const", "CONSTTK");
        reservedMap.put("int", "INTTK");
        reservedMap.put("break", "BREAKTK");
        reservedMap.put("continue", "CONTINUETK");
        reservedMap.put("if", "IFTK");
        reservedMap.put("else", "ELSETK");
        reservedMap.put("while", "WHILETK");
        reservedMap.put("getint", "GETINTTK");
        reservedMap.put("printf", "PRINTFTK");
        reservedMap.put("return", "RETURNTK");
        reservedMap.put("void", "VOIDTK");
    }
}
