import java.util.ArrayList;
import java.util.HashMap;

// 词法分析类
public class cifafenxi {
    // 当前字符在输入字符串中的索引
    public static int indexs = 0;

    // 上一个字符的索引位置
    public static int oldIndex = 0;

    // 当前行号
    public static int line = 1;

    // 当前Token
    public static String token = "";

    // 当前符号
    public static String symbol = "";

    // 当前整数值
    public static int num;

    // 当前字符
    public static char ch;

    // 输出结果列表
    public static ArrayList<String> output = new ArrayList<>();

    // 保留字映射表
    public static HashMap<String, String> reservedMap = new HashMap<>();

    // 格式字符计数表
    public static HashMap<Integer, Integer> formatNumber = new HashMap<>();

    // 获取下一个符号
    public static int getSym() {
        oldIndex = indexs;
        reservedMap = yingshe.reservedMap;
        clearToken();
        get_ch();

        // 判断是否到达文件尾
        if (isEOF()) {
            return -1;
        }

        // 处理标识符
        if (isLetter()) {
            while (isLetter() || Character.isDigit(ch)) {
                catToken();
                get_ch();
            }
            reTrack();
            if (!reserved()) {
                symbol = "IDENFR";
            }
            output.add(symbol + " " + token + " " + line);
        }

        // 处理数字
        else if (Character.isDigit(ch)) {
            while (Character.isDigit(ch)) {
                catToken();
                get_ch();
            }
            reTrack();
            num = Integer.parseInt(token);
            if (token.charAt(0) == '0' && token.length() > 1) {
                System.out.println("前导0错误!");
            }
            symbol = "INTCON";
            output.add(symbol + " " + num + " " + line);
        }

        // 处理注释和除法符号
        else if (ch == '/') {
            get_ch();
            if (ch == '*') {
                while (true) {
                    get_ch();
                    if (ch == '*') {
                        get_ch();
                        if (ch == '/') break;
                        else reTrack();
                    }
                }
            } else if (ch == '/') {
                get_ch();
                while (ch != '\n') {
                    get_ch();
                }
            } else {
                reTrack();
                symbol = "DIV";
                token = "/";
                output.add(symbol + " " + token + " " + line);
            }
        }

        // 处理字符串常量
        else if (isDquo()) {
            formatNumber.put(line, 0);
            int flag = 0;
            catToken();
            get_ch();
            while (isNormalChar() || isFormatChar()) {
                catToken();
                get_ch();
            }
            while (!isDquo()) {
                if (!isNormalChar() && !isFormatChar()) {
                    flag = 1;
                }
                catToken();
                get_ch();
            }
            symbol = "STRCON";
            catToken();
            output.add(symbol + " " + token + " " + line);
            if (flag == 1) {
                System.out.println("不符合词法" + ch);
                yingshe.error_output.set(line, line + " " + "a");
            }
        }

        // 处理关系运算符
        else if (isLss()) {
            catToken();
            get_ch();
            if (isAssign()) {
                catToken();
                symbol = "LEQ";
            } else {
                symbol = "LSS";
                reTrack();
            }
            output.add(symbol + " " + token + " " + line);
        } else if (isGre()) {
            catToken();
            get_ch();
            if (isAssign()) {
                catToken();
                symbol = "GEQ";
            } else {
                symbol = "GRE";
                reTrack();
            }
            output.add(symbol + " " + token + " " + line);
        } else if (isNot()) {
            catToken();
            get_ch();
            if (isAssign()) {
                catToken();
                symbol = "NEQ";
            } else {
                symbol = "NOT";
                reTrack();
            }
            output.add(symbol + " " + token + " " + line);
        } else if (isAssign()) {
            catToken();
            get_ch();
            if (isAssign()) {
                symbol = "EQL";
                catToken();
            } else {
                symbol = "ASSIGN";
                reTrack();
            }
            output.add(symbol + " " + token + " " + line);
        } else if (isAnd()) {
            catToken();
            get_ch();
            if (isAnd()) {
                symbol = "AND";
                catToken();
                output.add(symbol + " " + token + " " + line);
            } else {
                System.out.println("错误的&符号!");
                reTrack();
            }
        } else if (isOr()) {
            catToken();
            get_ch();
            if (isOr()) {
                symbol = "OR";
                catToken();
                output.add(symbol + " " + token + " " + line);
            } else {
                System.out.println("错误的|符号!");
                reTrack();
            }
        } else if (reservedS()) {
            token += ch;
            output.add(symbol + " " + ch + " " + line);
        }
        return 1;
    }

    // 判断是否为保留字符
    private static boolean reservedS() {
        symbol = yingshe.singleMap.get(ch);
        if (symbol != null) {
            return true;
        }
        return false;
    }

    // 判断是否为保留字
    private static boolean reserved() {
        symbol = reservedMap.get(token);
        if (symbol != null) {
            return true;
        }
        return false;
    }

    // 追加字符到Token
    private static void catToken() {
        token += ch;
    }

    // 回退一个字符
    private static void reTrack() {
        if (ch == '\n') line--;
        indexs--;
    }

    // 清空Token
    private static void clearToken() {
        token = "";
    }

    // 获取下一个字符
    public static void get_ch() {
        ch = yingshe.inputContent.charAt(indexs);
        indexs++;
        if (ch == '\n') {
            line++;
        }
    }

    // 判断是否为空白字符
    public static boolean isBlank() {
        return (ch == ' ' || ch == '\n' || ch == '\t' || ch == '\r' || ch == '\f');
    }

    // 判断是否到达文件尾
    public static boolean isEOF() {
        return indexs >= yingshe.inputContent.length();
    }

    // 判断是否为字母
    public static boolean isLetter() {
        return ch == '_' || Character.isLetter(ch);
    }

    // 判断是否为双引号
    public static boolean isDquo() {
        return ch == '\"';
    }

    // 判断是否为小于号
    public static boolean isLss() {
        return ch == '<';
    }

    // 判断是否为大于号
    public static boolean isGre() {
        return ch == '>';
    }

    // 判断是否为等号
    public static boolean isAssign() {
        return ch == '=';
    }

    // 判断是否为感叹号
    public static boolean isNot() {
        return ch == '!';
    }

    // 判断是否为与运算符
    public static boolean isAnd() {
        return ch == '&';
    }

    // 判断是否为或运算符
    public static boolean isOr() {
        return ch == '|';
    }

    // 判断是否为普通字符
    public static boolean isNormalChar() {
        int ascll = ch;
        return (ascll == 32 || ascll == 33 || (ascll >= 40 && ascll <= 126 && ascll != 92));
    }

    // 判断是否为格式字符
    public static boolean isFormatChar() {
        int ascll = ch;
        int ascll1 = yingshe.inputContent.charAt(indexs);
        if ((ascll == 37 && ascll1 == 100) || (ascll == 92 && ascll1 == 110)) {
            if (ascll == 37 && ascll1 == 100) {
                int num = formatNumber.get(line);
                num++;
                formatNumber.put(line, num);
            }
            catToken();
            get_ch();
            return true;
        }
        return false;
    }

    // 判断是否为换行符
    public static boolean isNewLine() {
        return ch == '\n';
    }
}
