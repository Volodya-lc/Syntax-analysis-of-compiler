import java.util.ArrayList;

// 定义符号表项类
public class fuhaobiao {
    // 符号表项的名称
    public String name;

    // 符号表项的类型
    public int type;

    // 符号表项的种类
    public int kind;

    // 符号表项的参数列表
    public ArrayList<Integer> parameterTable;

    // 符号表项的地址
    public int addr;

    // 记录该符号表项是否已经返回值（初始化为0表示未返回，1表示已返回）
    public int alreadyReturn = 0;

    // 构造函数，用于初始化符号表项
    public fuhaobiao(String name, int addr, int kind, int type) {
        this.name = name;
        this.addr = addr;
        this.kind = kind;
        this.type = type;
        parameterTable = new ArrayList<>(); // 初始化参数列表
    }

    // 向参数列表中插入参数
    public void insertPar(int t) {
        parameterTable.add(t);
    }
}
