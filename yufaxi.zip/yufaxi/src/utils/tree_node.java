package utils;

import java.util.ArrayList;

public class tree_node {

    public nodee nodeType;
    public String token;
    public String symbol;
    public ArrayList<tree_node> children = new ArrayList<>();
    public tree_node father = null;
    public int num;
    public boolean constnum = false;

    public tree_node(nodee tp) {
        this.nodeType = tp;
    }

    public void addTree(tree_node node) {
        node.father = this;
        children.add(node);
    }

    @Override
    public String toString() {
        String str = "" + this.nodeType + ": " + "'" + this.token + "'" + " = " + this.num + "\n";
        String length = " ";
        for (int i = 0; i < this.children.size(); i++) {
            length += " ";
        }
        if (this.children == null || this.children.size() == 0) {
            return str;
        }
        for (int i = 0; i < this.children.size(); i++) {
            str += length + "|______" + this.children.get(i).toString();
        }
        return str;
    }
}
