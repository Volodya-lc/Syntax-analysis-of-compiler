package utils;

import java.util.ArrayList;
import java.util.Objects;

public class treee {
    public static int index = -1;
    public static String line = "";
    public static String preline = "";
    public static String symbol = "";
    public static String token = "";
    public static int wrongExp = 0;
    public static ArrayList<String> lexicalOutput = new ArrayList<>();

    public static tree_node ParseTree(ArrayList<String> lexical) {
        lexicalOutput = lexical;
        return CompUnit();
    }

    private static tree_node CompUnit() {
        tree_node compUnit = new tree_node(nodee.COMPUNIT);
        getOne();
        while (true) {
            if (Objects.equals(symbol, "CONSTTK")) {
                compUnit.addTree(ConstDecl());
                continue;
            }
            if (Objects.equals(symbol, "INTTK")) {
                getOne();
                getOne();
                if (Objects.equals(symbol, "LPARENT")) {
                    reTrack();
                    reTrack();
                } else {
                    reTrack();
                    reTrack();
                    compUnit.addTree(VarDecl());
                    continue;
                }
            }
            break;
        }
        while (true) {
            if (Objects.equals(symbol, "VOIDTK") || Objects.equals(symbol, "INTTK")) {
                getOne();
                if (Objects.equals(symbol, "IDENFR")) {
                    getOne();
                    if (!Objects.equals(symbol, "LPARENT")) {
                        reTrack();
                        reTrack();
                    } else {
                        reTrack();
                        reTrack();
                        compUnit.addTree(FuncDef());
                    }
                    continue;
                }
                reTrack();
                break;
            }
        }

        compUnit.addTree(MainFuncDef());
        return compUnit;
    }

    private static tree_node ConstDecl() {
        tree_node constDecl = new tree_node(nodee.CONSTDECL);
        constDecl.addTree(Terminal());
        constDecl.addTree(Terminal());
        constDecl.addTree(ConstDef());
        while (true) {
            if (Objects.equals(symbol, "COMMA")) {
                constDecl.addTree(Terminal());
                constDecl.addTree(ConstDef());
                continue;
            }
            break;
        }
        if (Objects.equals(symbol, "SEMICN")) {
            constDecl.addTree(Terminal());
        }
        return constDecl;
    }

    private static tree_node VarDecl() {
        tree_node varDecl = new tree_node(nodee.VARDECL);
        varDecl.addTree(Terminal());
        varDecl.addTree(VarDef());
        while (true) {
            if (Objects.equals(symbol, "COMMA")) {
                varDecl.addTree(Terminal());
                varDecl.addTree(VarDef());
                continue;
            }
            break;
        }
        varDecl.addTree(Terminal());
        return varDecl;
    }

    public static tree_node FuncDef() {
        tree_node funcDef = new tree_node(nodee.FUNCDEF);
        funcDef.addTree(FuncType());
        funcDef.addTree(Terminal());
        funcDef.addTree(Terminal());
        if (Objects.equals(symbol, "INTTK")) {
            funcDef.addTree(FuncFParams());
        }
        funcDef.addTree(Terminal());
        funcDef.addTree(Block());

        return funcDef;
    }

    public static tree_node MainFuncDef() {
        tree_node mainFuncDef = new tree_node(nodee.MAINFUNCDEF);
        mainFuncDef.addTree(Terminal());
        mainFuncDef.addTree(Terminal());
        mainFuncDef.addTree(Terminal());
        mainFuncDef.addTree(Terminal());
        mainFuncDef.addTree(Block());
        return mainFuncDef;
    }

    public static tree_node ConstDef() {
        tree_node constDef = new tree_node(nodee.CONSTDEF);
        constDef.addTree(Terminal());
        while (true) {
            if (Objects.equals(symbol, "LBRACK")) {
                constDef.addTree(Terminal());
                constDef.addTree(ConstExp());
                constDef.addTree(Terminal());
                continue;
            }
            break;
        }
        constDef.addTree(Terminal());
        constDef.addTree(ConstInitVal());
        return constDef;
    }

    public static tree_node VarDef() {
        tree_node varDef = new tree_node(nodee.VARDEF);
        varDef.addTree(Terminal());
        while (true) {
            if (Objects.equals(symbol, "LBRACK")) {
                varDef.addTree(Terminal());
                varDef.addTree(ConstExp());
                varDef.addTree(Terminal());
                continue;
            }
            break;
        }
        if (Objects.equals(symbol, "ASSIGN")) {
            varDef.addTree(Terminal());
            varDef.addTree(InitVal());
        }
        return varDef;
    }

    public static tree_node FuncFParams() {
        tree_node funcFParam = new tree_node(nodee.FUNCFPARAMS);
        funcFParam.addTree(FuncFParam());
        while (true) {
            if (Objects.equals(symbol, "COMMA")) {
                funcFParam.addTree(Terminal());
                funcFParam.addTree(FuncFParam());
                continue;
            }
            break;
        }
        return funcFParam;
    }

    public static tree_node Block() {
        tree_node block = new tree_node(nodee.BLOCK);
        block.addTree(Terminal());
        while (true) {
            if (!Objects.equals(symbol, "RBRACE")) {
                if (Objects.equals(symbol, "CONSTTK")) {
                    block.addTree(ConstDecl());
                    continue;
                } else if (Objects.equals(symbol, "INTTK")) {
                    block.addTree(VarDecl());
                    continue;
                } else {
                    block.addTree(Stmt());
                    continue;
                }
            }
            break;
        }
        block.addTree(Terminal());
        return block;
    }

    public static tree_node ConstExp() {
        tree_node constExp = new tree_node(nodee.CONSTEXP);
        constExp.addTree(AddExp());
        return constExp;
    }

    public static tree_node ConstInitVal() {
        tree_node constInitVal = new tree_node(nodee.CONSTINITVAL);
        if (Objects.equals(symbol, "LBRACE")) {
            constInitVal.addTree(Terminal());
            if (!Objects.equals(symbol, "RBRACE")) {
                constInitVal.addTree(ConstInitVal());
                while (true) {
                    if (Objects.equals(symbol, "COMMA")) {
                        constInitVal.addTree(Terminal());
                        constInitVal.addTree(ConstInitVal());
                        continue;
                    }
                    break;
                }
            }
            constInitVal.addTree(Terminal());
        } else {
            constInitVal.addTree(ConstExp());
        }
        return constInitVal;
    }

    public static tree_node InitVal() {
        tree_node initVal = new tree_node(nodee.INITVAL);
        if (Objects.equals(symbol, "LBRACE")) {
            initVal.addTree(Terminal());
            if (!Objects.equals(symbol, "RBRACE")) {
                initVal.addTree(InitVal());
                while (true) {
                    if (Objects.equals(symbol, "COMMA")) {
                        initVal.addTree(Terminal());
                        initVal.addTree(InitVal());
                        continue;
                    }
                    break;
                }
            }
            initVal.addTree(Terminal());
        } else {
            initVal.addTree(Exp());
        }
        return initVal;
    }

    public static tree_node FuncFParam() {
        tree_node funcFParam = new tree_node(nodee.FUNCFPARAM);
        funcFParam.addTree(Terminal());
        funcFParam.addTree(Terminal());

        if (Objects.equals(symbol, "LBRACK")) {
            funcFParam.addTree(Terminal());
            funcFParam.addTree(Terminal());
            while (true) {
                if (Objects.equals(symbol, "LBRACK")) {
                    funcFParam.addTree(Terminal());
                    funcFParam.addTree(ConstExp());
                    funcFParam.addTree(Terminal());
                    continue;
                }
                break;
            }
        }
        return funcFParam;
    }

    public static tree_node AddExp() {
        tree_node addExp = new tree_node(nodee.ADDEXP);
        ArrayList<tree_node> temp = new ArrayList<>();
        temp.add(MulExp());
        while (true) {
            if (Objects.equals(symbol, "PLUS") || Objects.equals(symbol, "MINU")) {
                temp.add(Terminal());
                temp.add(MulExp());
                continue;
            }
            break;
        }
        int calPos = 1;
        int length = temp.size();
        int cur = 0;
        while (calPos <= length - 2) {
            tree_node addExp_temp = new tree_node(nodee.ADDEXP);
            while (cur < calPos) {
                addExp_temp.addTree(temp.get(cur));
                cur++;
            }
            cur--;
            temp.set(cur, addExp_temp);
            calPos += 2;
        }
        if (length >= 3) {
            addExp.addTree(temp.get(length - 3));
            addExp.addTree(temp.get(length - 2));
            addExp.addTree(temp.get(length - 1));
        } else {
            addExp.addTree(temp.get(0));
        }
        return addExp;
    }

    public static tree_node Exp() {
        tree_node exp = new tree_node(nodee.EXP);
        exp.addTree(AddExp());
        return exp;
    }

    /*
    Stmt → LVal '=' Exp ';'     | [Exp] ';'     | Block
    | LVal = 'getint''('')'';'

    | 'if' '(' Cond ')' Stmt [ 'else' Stmt ]     | 'while' '(' Cond ')' Stmt
    | 'break' ';' | 'continue' ';'
    | 'return' [Exp] ';'     | 'printf''('FormatString{,Exp}')'';'
    */
    public static tree_node Stmt() {
        tree_node stmt = new tree_node(nodee.STMT);
        if (Objects.equals(symbol, "LBRACE")) {
            stmt.addTree(Block());
        } else if (Objects.equals(symbol, "IFTK")) {
            stmt.addTree(Terminal());
            stmt.addTree(Terminal());
            stmt.addTree(Cond());
            stmt.addTree(Terminal());
            stmt.addTree(Stmt());
            if (Objects.equals(symbol, "ELSETK")) {
                stmt.addTree(Terminal());
                stmt.addTree(Stmt());
            }
        } else if (Objects.equals(symbol, "WHILETK")) {
            stmt.addTree(Terminal());
            stmt.addTree(Terminal());
            stmt.addTree(Cond());
            stmt.addTree(Terminal());
            stmt.addTree(Stmt());
        } else if (Objects.equals(symbol, "BREAKTK")) {
            stmt.addTree(Terminal());
            stmt.addTree(Terminal());
        } else if (Objects.equals(symbol, "CONTINUETK")) {
            stmt.addTree(Terminal());
            stmt.addTree(Terminal());
        } else if (Objects.equals(symbol, "RETURNTK")) {
            stmt.addTree(Terminal());
            int preIndex = index;
            tree_node treeNode = Exp();
            if (wrongExp == 1) {
                wrongExp = 0;
                index = preIndex;
                stmt.addTree(Terminal());
                return stmt;
            }
            stmt.addTree(treeNode);
            stmt.addTree(Terminal());
        } else if (Objects.equals(symbol, "PRINTFTK")) {
            stmt.addTree(Terminal());
            stmt.addTree(Terminal());
            stmt.addTree(Terminal());
            while (true) {
                if (Objects.equals(symbol, "COMMA")) {
                    stmt.addTree(Terminal());
                    stmt.addTree(Exp());
                    continue;
                }
                break;
            }
            stmt.addTree(Terminal());
            stmt.addTree(Terminal());
        } else if (Objects.equals(symbol, "IDENFR")) {
            int preIndex = index;
            int tempWrong = wrongExp;
            tree_node temp = LVal();
            wrongExp = tempWrong;
            if (!Objects.equals(symbol, "ASSIGN")) {
                index = preIndex - 1;
                getOne();
                if (!Objects.equals(symbol, "SEMICN")) {
                    stmt.addTree(Exp());
                }
                stmt.addTree(Terminal());
                return stmt;
            }
            stmt.addTree(temp);
            stmt.addTree(Terminal());
            if (Objects.equals(symbol, "GETINTTK")) {
                stmt.addTree(Terminal());
                stmt.addTree(Terminal());
                stmt.addTree(Terminal());
                stmt.addTree(Terminal());
            } else {
                stmt.addTree(Exp());
                stmt.addTree(Terminal());
            }
        } else {
            if (!Objects.equals(symbol, "SEMICN")) {
                stmt.addTree(Exp());
            }
            stmt.addTree(Terminal());
        }
        return stmt;
    }

    public static tree_node MulExp() {
        tree_node mulExp = new tree_node(nodee.MULEXP);
        ArrayList<tree_node> temp = new ArrayList<>();
        temp.add(UnaryExp());
        while (true) {
            if (Objects.equals(symbol, "MULT")
                    || Objects.equals(symbol, "DIV")
                    || Objects.equals(symbol, "MOD")) {
                temp.add(Terminal());
                temp.add(UnaryExp());
                continue;
            }
            break;
        }
        int calPos = 1, length = temp.size(), cur = 0;
        while (calPos <= length - 2) {
            tree_node mulExp_temp = new tree_node(nodee.MULEXP);
            while (cur < calPos) {
                mulExp_temp.addTree(temp.get(cur));
                cur++;
            }
            cur--;
            temp.set(cur, mulExp_temp);
            calPos += 2;
        }
        if (length >= 3) {
            mulExp.addTree(temp.get(length - 3));
            mulExp.addTree(temp.get(length - 2));
            mulExp.addTree(temp.get(length - 1));
        } else {
            mulExp.addTree(temp.get(0));
        }
        return mulExp;
    }

    public static tree_node UnaryExp() {
        tree_node unaryExp = new tree_node(nodee.UNARYEXP);
        getOne();
        String symbol1 = symbol;
        reTrack();
        if (Objects.equals(symbol, "IDENFR") && Objects.equals(symbol1, "LPARENT")) {
            unaryExp.addTree(Terminal());
            unaryExp.addTree(Terminal());
            if (!Objects.equals(symbol, "RPARENT")) {
                unaryExp.addTree(FuncRParams());
            }
            unaryExp.addTree(Terminal());
        } else if (Objects.equals(symbol, "PLUS")
                || Objects.equals(symbol, "MINU")
                || Objects.equals(symbol, "NOT")) {
            unaryExp.addTree(UnaryOp());
            unaryExp.addTree(UnaryExp());
        } else {
            unaryExp.addTree(PrimaryExp());
        }
        return unaryExp;
    }

    public static tree_node PrimaryExp() {
        tree_node primaryExp = new tree_node(nodee.PRIMARYEXP);
        if (Objects.equals(symbol, "LPARENT")) {
            primaryExp.addTree(Terminal());
            primaryExp.addTree(Exp());
            primaryExp.addTree(Terminal());
        } else if (Objects.equals(symbol, "IDENFR")) {
            primaryExp.addTree(LVal());
        } else if (Objects.equals(symbol, "INTCON")) {
            primaryExp.addTree(Number());
        } else {
            wrongExp = 1;
        }
        return primaryExp;
    }

    public static tree_node FuncRParams() {
        tree_node funcRParams = new tree_node(nodee.FUNCRPARAMS);
        funcRParams.addTree(Exp());
        while (true) {
            if (Objects.equals(symbol, "COMMA")) {
                funcRParams.addTree(Terminal());
                funcRParams.addTree(Exp());
                continue;
            }
            break;
        }
        return funcRParams;
    }

    public static tree_node Cond() {
        tree_node cond = new tree_node(nodee.COND);
        cond.addTree(LOrExp());
        return cond;
    }

    public static tree_node LOrExp() {
        tree_node lorExp = new tree_node(nodee.LOREXP);
        ArrayList<tree_node> temp = new ArrayList<>();
        temp.add(LAndExp());
        while (true) {
            if (Objects.equals(symbol, "OR")) {
                temp.add(Terminal());
                temp.add(LAndExp());
                continue;
            }
            break;
        }
        int calPos = 1, length = temp.size(), cur = 0;
        while (calPos <= length - 2) {
            tree_node LOrExp_temp = new tree_node(nodee.LOREXP);
            while (cur < calPos) {
                LOrExp_temp.addTree(temp.get(cur));
                cur++;
            }
            cur--;
            temp.set(cur, LOrExp_temp);
            calPos += 2;
        }
        if (length >= 3) {
            lorExp.addTree(temp.get(length - 3));
            lorExp.addTree(temp.get(length - 2));
            lorExp.addTree(temp.get(length - 1));
        } else {
            lorExp.addTree(temp.get(0));
        }
        return lorExp;
    }

    public static tree_node LAndExp() {
        tree_node landExp = new tree_node(nodee.LANDEXP);
        ArrayList<tree_node> temp = new ArrayList<>();
        temp.add(EqExp());
        while (true) {
            if (Objects.equals(symbol, "AND")) {
                temp.add(Terminal());
                temp.add(EqExp());
                continue;
            }
            break;
        }
        int calPos = 1, length = temp.size(), cur = 0;
        while (calPos <= length - 2) {
            tree_node LandExp_temp = new tree_node(nodee.LANDEXP);
            while (cur < calPos) {
                LandExp_temp.addTree(temp.get(cur));
                cur++;
            }
            cur--;
            temp.set(cur, LandExp_temp);
            calPos += 2;
        }
        if (length >= 3) {
            landExp.addTree(temp.get(length - 3));
            landExp.addTree(temp.get(length - 2));
            landExp.addTree(temp.get(length - 1));
        } else {
            landExp.addTree(temp.get(0));
        }
        return landExp;
    }

    public static tree_node EqExp() {
        tree_node eqExp = new tree_node(nodee.EQEXP);
        ArrayList<tree_node> temp = new ArrayList<>();
        temp.add(RealExp());
        while (true) {
            if (Objects.equals(symbol, "EQL") || Objects.equals(symbol, "NEQ")) {
                temp.add(Terminal());
                temp.add(RealExp());
                continue;
            }
            break;
        }
        int calPos = 1, length = temp.size(), cur = 0;
        while (calPos <= length - 2) {
            tree_node eqExp_temp = new tree_node(nodee.EQEXP);
            while (cur < calPos) {
                eqExp_temp.addTree(temp.get(cur));
                cur++;
            }
            cur--;
            temp.set(cur, eqExp_temp);
            calPos += 2;
        }
        if (length >= 3) {
            eqExp.addTree(temp.get(length - 3));
            eqExp.addTree(temp.get(length - 2));
            eqExp.addTree(temp.get(length - 1));
        } else {
            eqExp.addTree(temp.get(0));
        }
        return eqExp;
    }

    public static tree_node RealExp() {
        tree_node relExp = new tree_node(nodee.RELEXP);
        ArrayList<tree_node> temp = new ArrayList<>();
        temp.add(AddExp());
        while (true) {
            if (Objects.equals(symbol, "LSS")
                    || Objects.equals(symbol, "LEQ")
                    || Objects.equals(symbol, "GRE")
                    || Objects.equals(symbol, "GEQ")) {
                temp.add(Terminal());
                temp.add(AddExp());
                continue;
            }
            break;
        }
        int calPos = 1, length = temp.size(), cur = 0;
        while (calPos <= length - 2) {
            tree_node RelExp_temp = new tree_node(nodee.RELEXP);
            while (cur < calPos) {
                RelExp_temp.addTree(temp.get(cur));
                cur++;
            }
            cur--;
            temp.set(cur, RelExp_temp);
            calPos += 2;
        }
        if (length >= 3) {
            relExp.addTree(temp.get(length - 3));
            relExp.addTree(temp.get(length - 2));
            relExp.addTree(temp.get(length - 1));
        } else {
            relExp.addTree(temp.get(0));
        }
        return relExp;
    }

    public static tree_node LVal() {
        tree_node lVal = new tree_node(nodee.LVAL);
        lVal.addTree(Terminal());
        while (true) {
            if (Objects.equals(symbol, "LBRACK")) {
                lVal.addTree(Terminal());
                lVal.addTree(Exp());
                lVal.addTree(Terminal());
                continue;
            }
            break;
        }
        return lVal;
    }

    public static tree_node UnaryOp() {
        tree_node unaryOp = new tree_node(nodee.UNARYOP);
        unaryOp.addTree(Terminal());
        return unaryOp;
    }

    public static tree_node FuncType() {
        tree_node funcType = new tree_node(nodee.FUNCTYPE);
        funcType.addTree(Terminal());
        return funcType;
    }

    public static tree_node Number() {
        tree_node number = new tree_node(nodee.NUMBER);
        number.addTree(Terminal());
        return number;
    }

    public static int getOne() {
        index++;

        if (index >= lexicalOutput.size()) {
            return -1;
        }
        preline = line;
        String s = lexicalOutput.get(index);
        int space = s.indexOf(' ');
        int last = s.lastIndexOf(' ');
        symbol = s.substring(0, space);
        token = s.substring(space + 1, last);
        line = s.substring(last + 1);
        return 1;
    }

    public static void reTrack() {
        index--;
        preline = line;
        String s = lexicalOutput.get(index);
        int space = s.indexOf(' ');
        int last = s.lastIndexOf(' ');
        symbol = s.substring(0, space);
        token = s.substring(space + 1, last);
        line = s.substring(last + 1);
    }

    public static tree_node Terminal() {
        tree_node terminal = new tree_node(nodee.TERMINAL);
        terminal.symbol = symbol;
        terminal.token = token;
        getOne();
        return terminal;
    }
}
