#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <cctype>
#include <unordered_map>
#include <map>

using namespace std;

// �ʷ�����ģ��
unordered_map<string, string> tokenMap = {
    {"main", "MAINTK"}, {"while", "WHILETK"}, {"const", "CONSTTK"}, {"int", "INTTK"},
    {"break", "BREAKTK"}, {"continue", "CONTINUETK"}, {"if", "IFTK"}, {"else", "ELSETK"},
    {"void", "VOIDTK"}, {"return", "RETURNTK"}, {"printf", "PRINTFTK"}, {"getint", "GETINTTK"},
    {"&&", "AND"}, {"||", "OR"}, {"==", "EQL"}, {"!=", "NEQ"}, {"<=", "LEQ"}, {">=", "GEQ"},
    {"<", "LSS"}, {">", "GRE"}, {"=", "ASSIGN"}, {"+", "PLUS"}, {"-", "MINU"},
    {"*", "MULT"}, {"/", "DIV"}, {"%", "MOD"}, {"!", "NOT"}, {";", "SEMICN"},
    {",", "COMMA"}, {"(", "LPARENT"}, {")", "RPARENT"}, {"[", "LBRACK"}, {"]", "RBRACK"},
    {"{", "LBRACE"}, {"}", "RBRACE"}
};

vector<pair<string, string>> tokens;
int q = 0;
ofstream output;

bool isKeyword(const string& str) {
    return tokenMap.find(str) != tokenMap.end();
}

bool isIdentifier(char c) {
    return isalpha(c) || c == '_';
}

bool isDigit(char c) {
    return isdigit(c);
}

void classify_token(const string& token) {
    if (isKeyword(token)) {
        tokens.emplace_back(tokenMap[token], token);
    }
    else if (isIdentifier(token[0])) {
        tokens.emplace_back("IDENFR", token);
    }
    else if (isDigit(token[0])) {
        tokens.emplace_back("INTCON", token);
    }
}

void tokenize(const string& code) {
    bool in_string = false;
    bool in_single_comment = false;
    bool in_multi_comment = false;
    string current_token;

    for (size_t i = 0; i < code.size(); ++i) {
        char ch = code[i];
        if (in_single_comment) {
            if (ch == '\n') in_single_comment = false;
            continue;
        }

        if (in_multi_comment) {
            if (ch == '*' && i + 1 < code.size() && code[i + 1] == '/') {
                in_multi_comment = false;
                i++;
            }
            continue;
        }

        if (in_string) {
            current_token += ch;
            if (ch == '"' && (i == 0 || code[i - 1] != '\\')) {
                tokens.emplace_back("STRCON", current_token);
                in_string = false;
                current_token.clear();
            }
            continue;
        }

        if (ch == '"') {
            in_string = true;
            current_token += ch;
            continue;
        }

        if (ch == '/') {
            if (i + 1 < code.size() && code[i + 1] == '/') {
                in_single_comment = true;
                i++;
                continue;
            }
            if (i + 1 < code.size() && code[i + 1] == '*') {
                in_multi_comment = true;
                i++;
                continue;
            }
        }

        if (isspace(ch)) {
            if (!current_token.empty()) {
                classify_token(current_token);
                current_token.clear();
            }
            continue;
        }

        if (isalnum(ch) || ch == '_') {
            current_token += ch;
        } else {
            if (!current_token.empty()) {
                classify_token(current_token);
                current_token.clear();
            }

            string next_two_chars = code.substr(i, 2);
            if (next_two_chars == "!=" || next_two_chars == "==" || next_two_chars == "&&" || next_two_chars == "||" ||
                next_two_chars == "<=" || next_two_chars == ">=") {
                classify_token(next_two_chars);
                i++;
            } else {
                classify_token(string(1, ch));
            }
        }
    }

    if (!current_token.empty()) {
        classify_token(current_token);
    }
}

void lexAnalysis(const string& inputFile, const string& outputFile) {
    ifstream infile(inputFile);
    ofstream outfile(outputFile);

    if (!infile.is_open() || !outfile.is_open()) {
        cerr << "Error opening files!" << endl;
        return;
    }

    string code((istreambuf_iterator<char>(infile)), istreambuf_iterator<char>());
    tokenize(code);

    for (const auto& token : tokens) {
        outfile << token.first << " " << token.second << endl;
    }

    infile.close();
    outfile.close();
}

// �﷨����ģ��
void MatchToken(const string& expected) {
    if (tokens[q].first == expected) {
        output << tokens[q].first << " " << tokens[q].second << endl;
        q++;
    } else {
        cerr << "Unexpected token: " << tokens[q].first << ", expected: " << expected << endl;
        exit(1);
    }
}

void MatchCompUnit();
void MatchDecl();
void MatchConstDecl();
void MatchIntConst();
void MatchNumber();
void MatchBType();
void MatchConstDef();
void MatchConstInitVal();
void MatchVarDecl();
void MatchVarDef();
void MatchInitVal();
void MatchFuncDef();
void MatchMainFuncDef();
void MatchFuncType();
void MatchFuncFParams();
void MatchFuncFParam();
void MatchBlock();
void MatchBlockItem();
void MatchStmt();
void MatchExp();
void MatchCond();
void MatchLVal();
void MatchPrimaryExp();
void MatchUnaryOp();
void MatchFuncRParams();
void MatchMulExp();
void MatchMulExp2();
void MatchUnaryExp();
void MatchAddExp();
void MatchAddExp2();
void MatchRelExp();
void MatchRelExp2();
void MatchEqExp();
void MatchEqExp2();
void MatchLAndExp();
void MatchLAndExp2();
void MatchLOrExp();
void MatchLOrExp2();
void MatchConstExp();
void MatchPrint();
void MatchGetint();
void MatchReturn();

void GrammarAnalysis() {
    q = 0;
    output.open("output.txt", ios::app);
    MatchCompUnit();
    output.close();
}

void MatchCompUnit() {
    while ((tokens[q].first == "INTTK" || tokens[q].first == "CHARTK") && tokens[q + 2].first != "LPARENT" || tokens[q].first == "CONSTTK") {
        MatchDecl();
    }
    while ((tokens[q].first == "INTTK" || tokens[q].first == "CHARTK" || tokens[q].first == "VOIDTK") && tokens[q + 1].first == "IDENFR" && tokens[q + 2].first == "LPARENT") {
        MatchFuncDef();
    }
    if (tokens[q].first == "INTTK" && tokens[q + 1].first == "MAINTK") {
        MatchMainFuncDef();
    }
    output << "<CompUnit>\n";
}

void MatchDecl() {
    if (tokens[q].first == "CONSTTK") {
        MatchConstDecl();
    } else {
        MatchVarDecl();
    }
}

void MatchConstDecl() {
    MatchToken("CONSTTK");
    MatchBType();
    MatchConstDef();
    while (tokens[q].first == "COMMA") {
        MatchToken("COMMA");
        MatchConstDef();
    }
    MatchToken("SEMICN");
    output << "<ConstDecl>\n";
}

void MatchIntConst() {
    if (tokens[q].second[0] == '0' && tokens[q].second.length() > 1) {
        cerr << "Error: Invalid integer constant" << endl;
        exit(1);
    } else
        MatchToken("INTCON");
    output << "<Number>\n";
}

void MatchNumber() {
    if (tokens[q].first == "PLUS") MatchToken("PLUS");
    else if (tokens[q].first == "MINU") MatchToken("MINU");
    MatchIntConst();
}

void MatchBType() {
    if (tokens[q].first == "INTTK") MatchToken("INTTK");
    else if (tokens[q].first == "CHARTK") MatchToken("CHARTK");
}

void MatchConstDef() {
    MatchToken("IDENFR");
    while (tokens[q].first == "LBRACK") {
        MatchToken("LBRACK");
        MatchConstExp();
        MatchToken("RBRACK");
    }
    MatchToken("ASSIGN");
    MatchConstInitVal();
    output << "<ConstDef>\n";
}

void MatchConstInitVal() {
    if (tokens[q].first != "LBRACE") {
        MatchConstExp();
    } else {
        MatchToken("LBRACE");
        if (tokens[q].first != "RBRACE") {
            MatchConstInitVal();
            while (tokens[q].first == "COMMA") {
                MatchToken("COMMA");
                MatchConstInitVal();
            }
        }
        MatchToken("RBRACE");
    }
    output << "<ConstInitVal>\n";
}

void MatchVarDecl() {
    MatchBType();
    MatchVarDef();
    while (tokens[q].first == "COMMA") {
        MatchToken("COMMA");
        MatchVarDef();
    }
    MatchToken("SEMICN");
    output << "<VarDecl>\n";
}

void MatchVarDef() {
    MatchToken("IDENFR");
    while (tokens[q].first == "LBRACK") {
        MatchToken("LBRACK");
        MatchConstExp();
        MatchToken("RBRACK");
    }
    if (tokens[q].first == "ASSIGN") {
        MatchToken("ASSIGN");
        MatchInitVal();
    }
    output << "<VarDef>\n";
}

void MatchInitVal() {
    if (tokens[q].first != "LBRACE") {
        MatchExp();
    } else {
        MatchToken("LBRACE");
        if (tokens[q].first != "RBRACE") {
            MatchInitVal();
            while (tokens[q].first == "COMMA") {
                MatchToken("COMMA");
                MatchInitVal();
            }
        }
        MatchToken("RBRACE");
    }
    output << "<InitVal>\n";
}

void MatchFuncDef() {
    MatchFuncType();
    MatchToken("IDENFR");
    MatchToken("LPARENT");
    if (tokens[q].first != "RPARENT") MatchFuncFParams();
    MatchToken("RPARENT");
    MatchBlock();
    output << "<FuncDef>\n";
}

void MatchMainFuncDef() {
    MatchToken("INTTK");
    MatchToken("MAINTK");
    MatchToken("LPARENT");
    MatchToken("RPARENT");
    MatchBlock();
    output << "<MainFuncDef>\n";
}

void MatchFuncType() {
    if (tokens[q].first == "INTTK") MatchToken("INTTK");
    else if (tokens[q].first == "VOIDTK") MatchToken("VOIDTK");
    output << "<FuncType>\n";
}

void MatchFuncFParams() {
    MatchFuncFParam();
    while (tokens[q].first == "COMMA") {
        MatchToken("COMMA");
        MatchFuncFParam();
    }
    output << "<FuncFParams>\n";
}

void MatchFuncFParam() {
    MatchBType();
    MatchToken("IDENFR");
    if (tokens[q].first == "LBRACK") {
        MatchToken("LBRACK");
        MatchToken("RBRACK");
        while (tokens[q].first == "LBRACK") {
            MatchToken("LBRACK");
            MatchConstExp();
            MatchToken("RBRACK");
        }
    }
    output << "<FuncFParam>\n";
}

void MatchBlock() {
    MatchToken("LBRACE");
    while (tokens[q].first != "RBRACE") MatchBlockItem();
    MatchToken("RBRACE");
    output << "<Block>\n";
}

void MatchBlockItem() {
    if (tokens[q].first == "INTTK" || tokens[q].first == "CHARTK" || tokens[q].first == "CONSTTK") {
        MatchDecl();
    } else {
        MatchStmt();
    }
}

void MatchStmt() {
    if (tokens[q].first == "IDENFR") {
        if ((tokens[q + 1].first == "LBRACK" && tokens[q + 4].first == "LBRACK" && tokens[q + 7].first == "ASSIGN") 
            || (tokens[q + 1].first == "LBRACK" && tokens[q + 4].first == "ASSIGN") 
            || tokens[q + 1].first == "ASSIGN") {
            MatchLVal();
            MatchToken("ASSIGN");
            if (tokens[q].first == "GETINTTK") MatchGetint();
            else MatchExp();
        } else {
            MatchExp();
        }
        MatchToken("SEMICN");
    } else if (tokens[q].first == "LBRACE") {
        MatchBlock();
    } else if (tokens[q].first == "IFTK") {
        MatchToken("IFTK");
        MatchToken("LPARENT");
        MatchCond();
        MatchToken("RPARENT");
        MatchStmt();
        if (tokens[q].first == "ELSETK") {
            MatchToken("ELSETK");
            MatchStmt();
        }
    } else if (tokens[q].first == "WHILETK") {
        MatchToken("WHILETK");
        MatchToken("LPARENT");
        MatchCond();
        MatchToken("RPARENT");
        MatchStmt();
    } else if (tokens[q].first == "BREAKTK" || tokens[q].first == "CONTINUETK") {
        MatchToken(tokens[q].first);
        MatchToken("SEMICN");
    } else if (tokens[q].first == "RETURNTK") {
        MatchReturn();
        MatchToken("SEMICN");
    } else if (tokens[q].first == "PRINTFTK") {
        MatchPrint();
        MatchToken("SEMICN");
    } else if (tokens[q].first == "SEMICN") {
        MatchToken("SEMICN");
    }
    output << "<Stmt>\n";
}

void MatchExp() {
    MatchAddExp();
    output << "<Exp>\n";
}

void MatchCond() {
    MatchLOrExp();
    output << "<Cond>\n";
}

void MatchLVal() {
    MatchToken("IDENFR");
    while (tokens[q].first == "LBRACK") {
        MatchToken("LBRACK");
        MatchExp();
        MatchToken("RBRACK");
    }
    output << "<LVal>\n";
}

void MatchPrimaryExp() {
    if (tokens[q].first == "LPARENT") {
        MatchToken("LPARENT");
        MatchExp();
        MatchToken("RPARENT");
    } else if (tokens[q].first == "IDENFR") {
        MatchLVal();
    } else if (tokens[q].first == "INTCON" || tokens[q].first == "PLUS" || tokens[q].first == "MINU") {
        MatchNumber();
    }
    output << "<PrimaryExp>\n";
}

void MatchUnaryOp() {
    if (tokens[q].first == "PLUS" || tokens[q].first == "MINU" || tokens[q].first == "NOT") {
        MatchToken(tokens[q].first);
    }
    output << "<UnaryOp>\n";
}

void MatchFuncRParams() {
    MatchExp();
    while (tokens[q].first == "COMMA") {
        MatchToken("COMMA");
        MatchExp();
    }
    output << "<FuncRParams>\n";
}

void MatchMulExp() {
    MatchUnaryExp();
    MatchMulExp2();
}

void MatchMulExp2() {
    output << "<MulExp>\n";
    if (tokens[q].first == "MULT" || tokens[q].first == "DIV" || tokens[q].first == "MOD") {
        if (tokens[q].first == "MULT") MatchToken("MULT");
        else if (tokens[q].first == "DIV") MatchToken("DIV");
        else if (tokens[q].first == "MOD") MatchToken("MOD");
        MatchUnaryExp();
        MatchMulExp2();
    }
}

void MatchUnaryExp() {
    if (tokens[q].first == "PLUS" || tokens[q].first == "MINU" || tokens[q].first == "NOT") {
        MatchUnaryOp();
        MatchUnaryExp();
    } else if (tokens[q + 1].first == "LPARENT") {
        MatchToken("IDENFR");
        MatchToken("LPARENT");
        if (tokens[q].first != "RPARENT") MatchFuncRParams();
        MatchToken("RPARENT");
    } else {
        MatchPrimaryExp();
    }
    output << "<UnaryExp>\n";
}

void MatchAddExp() {
    MatchMulExp();
    MatchAddExp2();
}

void MatchAddExp2() {
    output << "<AddExp>\n";
    if (tokens[q].first == "PLUS" || tokens[q].first == "MINU") {
        if (tokens[q].first == "PLUS") MatchToken("PLUS");
        else if (tokens[q].first == "MINU") MatchToken("MINU");
        MatchMulExp();
        MatchAddExp2();
    }
}

void MatchRelExp() {
    if (tokens[q].first == "LSS") MatchToken("LSS");
    else if (tokens[q].first == "LEQ") MatchToken("LEQ");
    else if (tokens[q].first == "GRE") MatchToken("GRE");
    else if (tokens[q].first == "GEQ") MatchToken("GEQ");
    MatchAddExp();
    MatchRelExp2();
}

void MatchRelExp2() {
    output << "<RelExp>\n";
    if (tokens[q].first == "LSS" || tokens[q].first == "LEQ" || tokens[q].first == "GRE" || tokens[q].first == "GEQ") {
        if (tokens[q].first == "LSS") MatchToken("LSS");
        else if (tokens[q].first == "LEQ") MatchToken("LEQ");
        else if (tokens[q].first == "GRE") MatchToken("GRE");
        else if (tokens[q].first == "GEQ") MatchToken("GEQ");
        MatchAddExp();
        MatchRelExp2();
    }
}

void MatchEqExp() {
    if (tokens[q].first == "EQL") MatchToken("EQL");
    else if (tokens[q].first == "NEQ") MatchToken("NEQ");
    MatchRelExp();
    MatchEqExp2();
}

void MatchEqExp2() {
    output << "<EqExp>\n";
    if (tokens[q].first == "EQL" || tokens[q].first == "NEQ") {
        if (tokens[q].first == "EQL") MatchToken("EQL");
        else if (tokens[q].first == "NEQ") MatchToken("NEQ");
        MatchRelExp();
        MatchEqExp2();
    }
}

void MatchLAndExp() {
    if (tokens[q].first == "AND") MatchToken("AND");
    MatchEqExp();
    MatchLAndExp2();
}

void MatchLAndExp2() {
    output << "<LAndExp>\n";
    if (tokens[q].first == "AND") {
        MatchToken("AND");
        MatchEqExp();
        MatchLAndExp2();
    }
}

void MatchLOrExp() {
    if (tokens[q].first == "OR") MatchToken("OR");
    MatchLAndExp();
    MatchLOrExp2();
}

void MatchLOrExp2() {
    output << "<LOrExp>\n";
    if (tokens[q].first == "OR") {
        MatchToken("OR");
        MatchLAndExp();
        MatchLOrExp2();
    }
}

void MatchConstExp() {
    MatchAddExp();
    output << "<ConstExp>\n";
}

void MatchPrint() {
    MatchToken("PRINTFTK");
    MatchToken("LPARENT");
    if (tokens[q].first == "STRCON") MatchToken("STRCON");
    else MatchExp();
    while (tokens[q].first == "COMMA") {
        MatchToken("COMMA");
        MatchExp();
    }
    MatchToken("RPARENT");
}

void MatchGetint() {
    MatchToken("GETINTTK");
    MatchToken("LPARENT");
    MatchToken("RPARENT");
}

void MatchReturn() {
    MatchToken("RETURNTK");
    if (tokens[q].first != "SEMICN") MatchExp();
}

int main() {
    lexAnalysis("testfile.txt", "output.txt");
    GrammarAnalysis();
    return 0;
}
